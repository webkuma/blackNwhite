<script setup>
import { RouterView } from 'vue-router'
</script>

<template>
  <!-- 動態配置路由頁面 -->
  <RouterView />
</template>
